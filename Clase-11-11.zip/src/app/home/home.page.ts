import { Component } from '@angular/core';
import {IonContent, IonIcon, IonCard, IonCardContent, IonItem, IonInput, IonCheckbox, IonButton, IonChip, IonLabel,IonText} from '@ionic/angular/standalone';
import { addIcons } from 'ionicons';
import {cubeOutline,mailOutline,lockClosedOutline,logInOutline,logoGoogle,logoApple,shieldCheckmarkOutline} from 'ionicons/icons';
import {Router} from '@angular/router';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
  imports: [
    IonContent,
    IonIcon,
    IonCard,
    IonCardContent,
    IonItem,
    IonInput,
    IonCheckbox,
    IonButton,
    IonChip,
    IonLabel,
    FormsModule,
    CommonModule,
    IonText
  ],
})
export class HomePage {
  email = '';
  password = '';
  errorMessage = '';
  success = false;


  constructor(private router: Router) {
    // Registrar los iconos necesarios
    addIcons({
      'cube-outline': cubeOutline,
      'mail-outline': mailOutline,
      'lock-closed-outline': lockClosedOutline,
      'log-in-outline': logInOutline,
      'logo-google': logoGoogle,
      'logo-apple': logoApple,
      'shield-checkmark-outline': shieldCheckmarkOutline
    });
  }

  irRegister() {
    console.log('Navegando a la página de registro...');
    this.router.navigate(['/register']);
  }
  irCamara() {
    console.log('Navegando a la página de la cámara...');
    this.router.navigate(['/testcamara']);
  }
  login() {
    // Lógica de inicio de sesión
    console.log('Iniciando sesión...');
    console.log('Email:', this.email);
    console.log('Password:', this.password);
    if(this.email === 'vicente' && this.password === '1234') {
      this.router.navigate(['/listar']);
    }
    else {
      console.log('Credenciales incorrectas');
      this.errorMessage = 'Credenciales incorrectas. Por favor, inténtalo de nuevo.';
    }
  }
}
