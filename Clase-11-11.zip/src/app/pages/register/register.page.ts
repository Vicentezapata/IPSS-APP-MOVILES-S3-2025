import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { 
  IonContent, 
  IonIcon, 
  IonCard, 
  IonText,
  IonCardContent, 
  IonItem, 
  IonInput, 
  IonCheckbox, 
  IonButton, 
  IonChip, 
  IonLabel 
} from '@ionic/angular/standalone';
import { addIcons } from 'ionicons';
import { 
  cubeOutline, 
  personOutline, 
  mailOutline, 
  callOutline,
  lockClosedOutline, 
  lockOpenOutline,
  personAddOutline, 
  logoGoogle, 
  logoApple, 
  shieldCheckmarkOutline 
} from 'ionicons/icons';

@Component({
  selector: 'app-register',
  templateUrl: './register.page.html',
  styleUrls: ['./register.page.scss'],
  standalone: true,
  imports: [
    IonContent,
    IonText,
    IonIcon,
    IonCard,
    IonCardContent,
    IonItem,
    IonInput,
    IonCheckbox,
    IonButton,
    IonChip,
    IonLabel,
    CommonModule,
    FormsModule
  ]
})
export class RegisterPage implements OnInit {
  nombre = '';
  email = '';
  telefono = '';
  password = '';
  confirmarPassword = '';
  aceptarTerminos = false;
  errorMessage = '';
  success = false;
  contErrores = 0;

  constructor(private router: Router) {
    // Registrar los iconos necesarios
    addIcons({
      'cube-outline': cubeOutline,
      'person-outline': personOutline,
      'mail-outline': mailOutline,
      'call-outline': callOutline,
      'lock-closed-outline': lockClosedOutline,
      'lock-open-outline': lockOpenOutline,
      'person-add-outline': personAddOutline,
      'logo-google': logoGoogle,
      'logo-apple': logoApple,
      'shield-checkmark-outline': shieldCheckmarkOutline
    });
  }

  ngOnInit() {
  }

  validarRegistro() {
    // Lógica de validación de registro
    console.log('Validando registro...');
    console.log('Nombre:', this.nombre);
    console.log('Email:', this.email);
    console.log('Teléfono:', this.telefono);
    console.log('Contraseña:', this.password);
    console.log('Confirmar Contraseña:', this.confirmarPassword);
    console.log('Aceptar Términos:', this.aceptarTerminos);
    this.errorMessage = '';
    this.contErrores = 0;
    if(this.password !== this.confirmarPassword) {
      this.errorMessage += 'Las contraseñas no coinciden.\n';
      this.contErrores += 1;
    }
    if(!this.aceptarTerminos) {
      this.errorMessage += 'Debe aceptar los términos y condiciones.\n';
      this.contErrores += 1;
    }
    if(this.telefono.length < 10) {
      this.errorMessage += 'El número de teléfono es inválido.\n';
      this.contErrores += 1;
    }
    if(this.telefono === '') {
      this.errorMessage += 'El teléfono es obligatorio.\n';
      this.contErrores += 1;
    }
    if(this.email === '') {
      this.errorMessage += 'El email es obligatorio.\n';
      this.contErrores += 1;
    }
    if(this.nombre === '') {
      this.errorMessage += 'El nombre es obligatorio.\n';
      this.contErrores += 1;
    }
    console.log(this.errorMessage);
    console.log('Número de errores:', this.contErrores);
    if(this.contErrores === 0) {
      this.router.navigate(['/home']);
    }
  }

}
